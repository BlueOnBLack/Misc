W8CPUFeaturePatch

- Click "Remove PAE check" if your CPU doesn't support PAE.
- If your CPU doesn't support SSE2 or NX (missing PAE support implies missing NX support) click "Remove SSE2 and NX check".
- To enable support for more than one logical CPU core after patching NX, click "Fix hyper-threading in hal.dll" and "Fix hyper-threading in halmacpi.dll".
- If you want to get rid of the digital signature warning on boot after applying one of the patches above, click "Remove winload patchguard x86".
- Click "Remove various CPU feature checks in Windows 8.1 x64" if you want to skip some CPU feature checks (like CMPXCHG16B support) in Windows 8.1 x64.
- Click "Remove winload patchguard of Windows 8.1 x64" to skip the digital signature warning that appears on boot after applying the Windows 8.1 x64 check.