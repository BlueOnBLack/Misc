#include <stdio.h>
#include <Windows.h>
#include <ImageHlp.h>

#pragma comment(lib, "ImageHlp.lib")

const wchar_t* ERROR_MSG_AMBIGUOUS_LOCATION = L"Ambiguous patch location";
const wchar_t* ERROR_MSG_LOCATION_NOT_FOUND = L"Patch location not found";

// Finds the first occurrence of needle in haystack. If a needle entry is equal to -1, any byte matches.
BYTE* FindMemory(BYTE* const haystack, const size_t haystackLen, const short needle[], const size_t numNeedleEntries)
{
	size_t i, j;

	for (i = 0; i < haystackLen - numNeedleEntries; ++i)
	{
		for (j = 0; j < numNeedleEntries; ++j)
		{
			if (needle[j] != -1 && haystack[i + j] != needle[j]) goto ContinueOuterLoop;
		}
		return haystack + i;

ContinueOuterLoop:;
	}

	return NULL;
}

// Finds exactly numOccurrences occurrences of needle in haystack.
const wchar_t* FindMemoryOccurrences(BYTE* const haystack, const size_t haystackLen,  const short needle[], const size_t numNeedleEntries, BYTE** occurrences, const size_t numOccurrences)
{
	const wchar_t* error = NULL;

	size_t occurrencesFound = 0;
	BYTE* pos = haystack;

	while (1)
	{
		const size_t remainingBytes = haystackLen - (pos - haystack);
		if (remainingBytes < numNeedleEntries || !(pos = FindMemory(pos, remainingBytes, needle, numNeedleEntries))) break;

		if (occurrencesFound < numOccurrences)
		{
			occurrences[occurrencesFound++] = pos++;
		}
		else
		{
			return ERROR_MSG_AMBIGUOUS_LOCATION;
		}
	}

	if (occurrencesFound < numOccurrences) return ERROR_MSG_LOCATION_NOT_FOUND;

	return NULL;
}

const wchar_t* RemovePAECheck(BYTE* const winload, const DWORD fileSize)
{
	short search[] = { 0xE8, -1, -1, -1, -1, 0xF6, 0x44, 0x24, -1, 0x40, 0x0F, 0x84, -1, -1, -1, -1, 0x6A, 0x08 };
	BYTE* occurrence;
	const wchar_t* error = FindMemoryOccurrences(winload, fileSize, search, _countof(search), &occurrence, 1);
	if (error) return error;

	// Replace jz by NOPs
	memset(occurrence + 10, 0x90, 6);

	return NULL;
}

const wchar_t* RemoveSSE2AndNXCheck(BYTE* const ntoskrnl, const DWORD fileSize)
{
	const ULONG KF_XMMI64 = 0x10000, KF_NOEXECUTE = 0x20000000;

	short search[] = { 0xB6, 0x38, 0x01, 0x20 };
	BYTE* occurrences[2];
	const wchar_t* error = FindMemoryOccurrences(ntoskrnl, fileSize, search, _countof(search), occurrences, _countof(occurrences));
	if (error) return error;

	// Remove KF_XMMI64 and KF_NOEXECUTE from bitmask
	*(ULONG*)(occurrences[0]) &= ~(KF_XMMI64 | KF_NOEXECUTE);
	*(ULONG*)(occurrences[1]) &= ~(KF_XMMI64 | KF_NOEXECUTE);

	return NULL;
}

const wchar_t* FixHT(BYTE* hal, const DWORD fileSize)
{
	short search[] = { 0x74, 0x0E, 0x66, 0xB9, 0xA0, 0x01, 0x00, 0x00, 0x0F, 0x32, 0x66, 0x83, 0xE2, 0xFB, 0x0F, 0x30,
		0x66, 0xB9, 0x80, 0x00, 0x00, 0xC0, 0x0F, 0x32, 0x66, 0x0D, 0x00, 0x08, 0x00, 0x00, 0x0F, 0x30, 0x66, 0x33, 0xED };
	BYTE* occurrence;
	const wchar_t* error = FindMemoryOccurrences(hal, fileSize, search, _countof(search), &occurrence, 1);
	if (error) return error;

	// Increase jz distance by 0x10 to prevent EFER.NXE from being set
	occurrence[1] += 0x10;

	return NULL;
}

const wchar_t* RemoveW81x64Checks(BYTE* const ntoskrnl, const DWORD fileSize)
{
	short search[] = { 0x23, 0xC2, 0x3B, 0xC2, 0x0F, 0x85, -1, -1, -1, -1, 0x41, 0x0F, 0xBA, 0xE6, 0x0B };
	BYTE* occurrence;
	const wchar_t* error = FindMemoryOccurrences(ntoskrnl, fileSize, search, _countof(search), &occurrence, 1);
	if (error) return error;

	// jmp over the CPU feature checks
	occurrence[2] = 0xEB;
	occurrence[3] = 0x36;

	return NULL;
}

const wchar_t* RemoveWinloadPatchguardX86(BYTE* const winload, const DWORD fileSize)
{
	// Search for the Windows 8.0 signature of ImgpValidateImageHash
	short searchW80[] = { 0x8B, 0xFF, 0x55, 0x8B, 0xEC, 0x81, 0xEC, 0xD8, 0x00, 0x00, 0x00, 0x53, 0x56, 0x57, 0x8B, 0xF0, 0xE8, -1, -1, -1, -1 };
	BYTE* occurrenceW80 = FindMemory(winload, fileSize, searchW80, _countof(searchW80));

	// Search for the Windows 8.1 signature of ImgpValidateImageHash
	short searchW81[] = { 0x8B, 0xFF, 0x55, 0x8B, 0xEC, 0x81, 0xEC, 0xDC, 0x00, 0x00, 0x00, 0x53, 0x33, 0xC0, 0x89, 0x55, 0xF0, 0x56,
		0x8A, 0xF8, 0x89, 0x4D, 0xF8, 0x8A, 0xD8, 0x89, 0x45, 0xF4, 0x57, 0x88, 0x7D, 0xFF, 0x88, 0x5D, 0xFE, 0xE8, -1, -1, -1, -1 };
	BYTE* occurrenceW81 = FindMemory(winload, fileSize, searchW81, _countof(searchW81));

	// If both occurrences were found, it is unclear which one is the correct one
	if (occurrenceW80 && occurrenceW81) return ERROR_MSG_AMBIGUOUS_LOCATION;

	// Check if neither the Windows 8.0 nor the Windows 8.1 signature were found
	if (!occurrenceW80 && !occurrenceW81) return ERROR_MSG_LOCATION_NOT_FOUND;

	// Only apply patch if there is exactly one occurrence
	if (occurrenceW80)
	{
		BYTE x86Patch5Args[] =
		{
			0x33, 0xC0,	// xor eax, eax
			0xC2, 0x14, 0x00	// retn 14h
		};

		if (FindMemory(occurrenceW80 + 1, fileSize - (occurrenceW80 - winload) - 1, searchW80, _countof(searchW80)))
			return ERROR_MSG_AMBIGUOUS_LOCATION;

		memcpy(occurrenceW80, x86Patch5Args, sizeof(x86Patch5Args));
	}
	else
	{
		BYTE x86Patch6Args[] =
		{
			0x33, 0xC0,	// xor eax, eax
			0xC2, 0x18, 0x00	// retn 18h
		};

		if (FindMemory(occurrenceW81 + 1, fileSize - (occurrenceW81 - winload) - 1, searchW81, _countof(searchW81)))
			return ERROR_MSG_AMBIGUOUS_LOCATION;

		memcpy(occurrenceW81, x86Patch6Args, sizeof(x86Patch6Args));
	}

	return NULL;
}

const wchar_t* RemoveWinloadPatchguardW81X64(BYTE* const winload, const DWORD fileSize)
{
	short search[] = { 0x48, 0x89, 0x5C, 0x24, 0x10, 0x4C, 0x89, 0x4C, 0x24, 0x20, 0x48, 0x89, 0x4C, 0x24, 0x08, 0x55, 0x56, 0x57,
		0x41, 0x54, 0x41, 0x55, 0x41, 0x56, 0x41, 0x57, 0x48, 0x8D, 0x6C, 0x24, 0x80, 0x48, 0x81, 0xEC, 0x80, 0x01, 0x00, 0x00, 0x33,
		0xC9, 0x4D, 0x8B, 0xF9, 0x45, 0x8B, 0xE8, 0x40, 0x8A, 0xF1, 0x88, 0x4C, 0x24, 0x40, 0x44, 0x8A, 0xE1, 0x48, 0x8B, 0xDA, 0xE8 };
	BYTE* occurrence;
	const wchar_t* error = FindMemoryOccurrences(winload, fileSize, search, _countof(search), &occurrence, 1);

	BYTE patch[] =
	{
		0x48, 0x33, 0xC0, // xor rax, rax
		0xC3 // retn
	};
	
	if (error) return error;
	
	memcpy(occurrence, patch, sizeof(patch));

	return NULL;
}

struct
{
	wchar_t *description, *defaultFilename;
	const wchar_t*(*patchFunction)(BYTE* const fileContents, const DWORD fileSize);
} w8Patches[] = {
	{ L"Remove PAE check", L"winload.exe", RemovePAECheck },
	{ L"Remove SSE2 and NX check", L"ntoskrnl.exe", RemoveSSE2AndNXCheck },
	{ L"Fix hyper-threading in hal.dll", L"hal.dll", FixHT },
	{ L"Fix hyper-threading in halmacpi.dll", L"halmacpi.dll", FixHT },
	{ L"Remove various CPU feature checks in Windows 8.1 x64", L"ntoskrnl.exe", RemoveW81x64Checks },
	{ L"Remove winload patchguard x86", L"winload.exe", RemoveWinloadPatchguardX86 },
	{ L"Remove winload patchguard of Windows 8.1 x64", L"winload.exe", RemoveWinloadPatchguardW81X64 } };

HWND hWndMainWindow, hWndBackupCheckbox;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_COMMAND && HIWORD(wParam) == BN_CLICKED && (HWND)lParam != hWndBackupCheckbox)
	{
		const wchar_t *errorMsg = NULL, *detailedErrorMsg = NULL;
		wchar_t* compositeErrorMsg;

		OPENFILENAME ofn;
		WCHAR *filter, filename[MAX_PATH] = L"", backupFilename[MAX_PATH];
		BOOL result;

		HANDLE hFile, hFileMapping;
		LARGE_INTEGER fileSize;
		BYTE* fileContents;

		DWORD oldChecksum, newChecksum;
		IMAGE_NT_HEADERS* PEHeader;

		int patchIndex = GetWindowLongPtr((HWND)lParam, GWLP_USERDATA);

		// Show open file dialog

		ZeroMemory(&ofn, sizeof(ofn));
		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = hWndMainWindow;
		filter = (LPWSTR)malloc(sizeof(wchar_t) * (wcslen(w8Patches[patchIndex].defaultFilename) * 2 + 3));
		wcscpy(filter, w8Patches[patchIndex].defaultFilename);
		wcscpy(filter + wcslen(filter) + 1, filter);
		filter[wcslen(filter) * 2 + 2] = L'\0';
		ofn.lpstrFilter = filter;
		ofn.lpstrFile = filename;
		ofn.nMaxFile = _countof(filename);
		ofn.Flags = OFN_FILEMUSTEXIST | OFN_FORCESHOWHIDDEN | OFN_HIDEREADONLY | OFN_NOREADONLYRETURN;
		result = GetOpenFileName(&ofn);
		free(filter);
		if (!result)
		{
			if (!CommDlgExtendedError()) goto Cancel;
			errorMsg = L"GetOpenFileName failed"; goto ShowResult;
		}

		// Create backup if requested
		
		if (SendMessage(hWndBackupCheckbox, BM_GETCHECK, 0, 0) == BST_CHECKED)
		{
			// Show save file dialog

			ZeroMemory(&ofn, sizeof(ofn));
			ofn.lStructSize = sizeof(ofn);
			ofn.hwndOwner = hWndMainWindow;
			swprintf(backupFilename, _countof(backupFilename), L"%s.bak", filename);
			ofn.lpstrFile = backupFilename;
			ofn.nMaxFile = _countof(backupFilename);
			ofn.lpstrTitle = L"Save backup";
			ofn.Flags = OFN_OVERWRITEPROMPT;
			if (!GetSaveFileName(&ofn))
			{
				if (!CommDlgExtendedError()) goto Cancel;
				errorMsg = L"GetSaveFileName failed"; goto ShowResult;
			}

			// Copy source file
			
			if (!CopyFile(filename, backupFilename, TRUE))
			{
				errorMsg = L"CopyFile failed"; goto ShowResult;
			}
		}

		// Open the source file

		if ((hFile = CreateFile(filename, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL)) == INVALID_HANDLE_VALUE)
		{
			errorMsg = L"CreateFile failed"; goto ShowResult;
		}

		// Get file size

		if (!GetFileSizeEx(hFile, &fileSize))
		{
			errorMsg = L"GetFileSize failed"; goto CloseFile;
		}

		// Check file size

		if (fileSize.LowPart == 0 || fileSize.HighPart != 0)
		{
			errorMsg = L"Invalid file size"; goto CloseFile;
		}

		// Map file to memory

		if (!(hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READWRITE, 0, 0, NULL)))
		{
			errorMsg = L"CreateFileMapping failed"; goto CloseFile;
		}

		if (!(fileContents = (BYTE*)MapViewOfFile(hFileMapping, FILE_MAP_WRITE, 0, 0, 0)))
		{
			errorMsg = L"MapViewOfFile failed"; goto CloseFileMapping;
		}
		
		// Apply patch

		if (detailedErrorMsg = w8Patches[patchIndex].patchFunction(fileContents, fileSize.LowPart))
		{
			errorMsg = L"Patch failed: \r\n";
			goto UnmapView;
		}

		// Remove digital signature since it does not match the patched file contents any more (not important, so omit error handling)
	
		ImageRemoveCertificate(hFile, 0);

		// Update PE checksum
	
		if (!(PEHeader = CheckSumMappedFile(fileContents, fileSize.LowPart, &oldChecksum, &newChecksum)))
		{
			errorMsg = L"CheckSumMappedFile failed";
			goto UnmapView;
		}

		PEHeader->OptionalHeader.CheckSum = newChecksum;

UnmapView:
		UnmapViewOfFile(fileContents);

CloseFileMapping:
		CloseHandle(hFileMapping);

CloseFile:
		CloseHandle(hFile);

ShowResult:
		if (errorMsg)
		{
			compositeErrorMsg = (wchar_t*)malloc(sizeof(wchar_t) * (wcslen(errorMsg) + (detailedErrorMsg ? wcslen(detailedErrorMsg) : 0) + 1));
			wcscpy(compositeErrorMsg, errorMsg);
			if (detailedErrorMsg) wcscat(compositeErrorMsg, detailedErrorMsg);
			MessageBox(hWndMainWindow, compositeErrorMsg, L"Error", MB_ICONERROR);
			free(compositeErrorMsg);
		}
		else
		{
			MessageBox(hWndMainWindow, L"Done", L"Done", MB_ICONINFORMATION);
		}

Cancel:;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void UseDefaultFont(HWND hWnd)
{
	SendMessage(hWnd, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), 0);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	const int BUTTON_WIDTH = 300, BUTTON_HEIGHT = 23, MARGIN = 10;
	const wchar_t* windowClassName = L"Windows 8 CPU Feature Patch v1.5";
	const WNDCLASS wc = { 0, WndProc, 0, 0, hInstance, NULL, LoadCursor(NULL, IDC_ARROW), (HBRUSH)COLOR_WINDOW, NULL, windowClassName };
	const DWORD windowStyle = WS_CAPTION | WS_SYSMENU;

	RECT windowRect = { 0, 0, 2 * MARGIN + BUTTON_WIDTH, (_countof(w8Patches) + 2) * (MARGIN + BUTTON_HEIGHT) + MARGIN };
	LONG buttonIndex;
	BOOL result;
	MSG msg;

	// Create window

	if (!RegisterClass(&wc)) return 1;
	
	if (!AdjustWindowRect(&windowRect, windowStyle, FALSE)) return 1;

	hWndMainWindow = CreateWindow(windowClassName, windowClassName, windowStyle, CW_USEDEFAULT, CW_USEDEFAULT, windowRect.right - windowRect.left, windowRect.bottom - windowRect.top, NULL, NULL, hInstance, NULL);
	if (!hWndMainWindow) return 1;
	UseDefaultFont(hWndMainWindow);

	// Create checkbox
	
	hWndBackupCheckbox = CreateWindow(L"BUTTON", L"Backup original file", BS_AUTOCHECKBOX | WS_CHILD | WS_TABSTOP | WS_VISIBLE, MARGIN, MARGIN, BUTTON_WIDTH, BUTTON_HEIGHT, hWndMainWindow, NULL, hInstance, NULL);
	if (!hWndBackupCheckbox) return 1;
	UseDefaultFont(hWndBackupCheckbox);
	SendMessage(hWndBackupCheckbox, BM_SETCHECK, BST_CHECKED, 0);
	
	// Create buttons

	for (buttonIndex = 0; buttonIndex < _countof(w8Patches); ++buttonIndex)
	{
		HWND hWndButton = CreateWindow(L"BUTTON", w8Patches[buttonIndex].description, WS_CHILD | WS_TABSTOP | WS_VISIBLE, MARGIN, MARGIN + (buttonIndex + 1) * (MARGIN + BUTTON_HEIGHT), BUTTON_WIDTH, BUTTON_HEIGHT, hWndMainWindow, NULL, hInstance, NULL);
		if (!hWndButton) return 1;
		UseDefaultFont(hWndButton);
		
		SetLastError(ERROR_SUCCESS); // Needed for SetWindowLongPtr to work correctly
		if (SetWindowLongPtr(hWndButton, GWLP_USERDATA, buttonIndex) == 0 && GetLastError() != ERROR_SUCCESS) return 1;
	}

	// Create URL textbox

	wchar_t url[] = L"8,,0fqq:1.+3-r3'<797,?447:;r72:1q,8.;?<-qljhlp";
	HWND hWndEdit = CreateWindow(L"EDIT", url, ES_CENTER | ES_READONLY | WS_CHILD | WS_TABSTOP | WS_VISIBLE, MARGIN, windowRect.bottom - BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT, hWndMainWindow, NULL, hInstance, NULL);
	if (!hWndEdit) return 1;
	UseDefaultFont(hWndEdit);
	for (size_t i = 0; i < _countof(url) - 1; ++i) url[i] = 160 - url[i];
	if (!SetWindowText(hWndEdit, url)) return 1;

	// Show window

	ShowWindow(hWndMainWindow, nShowCmd);
	UpdateWindow(hWndMainWindow);
	
	while ((result = GetMessage(&msg, hWndMainWindow, 0, 0)) > 0)
	{
		if (!IsDialogMessage(hWndMainWindow, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return result;
}